<?php

use Latte\Runtime as LR;

/** source: /wp4-07/app/Presenters/templates/Post/show.latte */
final class Template82bf0f83b7 extends Latte\Runtime\Template
{
	protected const BLOCKS = [
		['content' => 'blockContent', 'title' => 'blockTitle'],
	];


	public function main(): array
	{
		extract($this->params);
		if ($this->getParentName()) {
			return get_defined_vars();
		}
		$this->renderBlock('content', get_defined_vars()) /* line 1 */;
		return get_defined_vars();
	}


	public function prepare(): void
	{
		extract($this->params);
		if (!$this->getReferringTemplate() || $this->getReferenceType() === "extends") {
			foreach (array_intersect_key(['comment' => '18'], $this->params) as $ʟ_v => $ʟ_l) {
				trigger_error("Variable \$$ʟ_v overwritten in foreach on line $ʟ_l");
			}
		}
		Nette\Bridges\ApplicationLatte\UIRuntime::initialize($this, $this->parentName, $this->blocks);
		
	}


	/** {block content} on line 1 */
	public function blockContent(array $ʟ_args): void
	{
		extract($this->params);
		extract($ʟ_args);
		unset($ʟ_args);
		echo '
<p><a href="';
		echo LR\Filters::escapeHtmlAttr($this->global->uiControl->link("Homepage:default")) /* line 3 */;
		echo '">← zpět na výpis příspěvků</a></p>

<div class="date">';
		echo LR\Filters::escapeHtmlText(($this->filters->date)($post->created_at, 'F j, Y')) /* line 5 */;
		echo '</div>

';
		$this->renderBlock('title', get_defined_vars()) /* line 7 */;
		echo '
<div class="post">';
		echo LR\Filters::escapeHtmlText($post->content) /* line 9 */;
		echo '</div>
<a href="';
		echo LR\Filters::escapeHtmlAttr($this->global->uiControl->link("Edit:edit", [$post->id])) /* line 10 */;
		echo '">Upravit příspěvek</a>
<h2>Vložte nový příspěvek</h2>

';
		/* line 13 */ $_tmp = $this->global->uiControl->getComponent("commentForm");
		if ($_tmp instanceof Nette\Application\UI\Renderable) $_tmp->redrawControl(null, false);
		$_tmp->render();
		echo '
<h2>Komentáře</h2>

<div class="comments">
';
		$iterations = 0;
		foreach ($comments as $comment) /* line 18 */ {
			echo '		<p><b>';
			if ($ʟ_if[3] = ($comment->email)) /* line 19 */ {
				echo '<a href="mailto:';
				echo LR\Filters::escapeHtmlAttr(LR\Filters::safeUrl($comment->email)) /* line 19 */;
				echo '">
';
			}
			echo '			';
			echo LR\Filters::escapeHtmlText($comment->name) /* line 20 */;
			echo "\n";
			if ($ʟ_if[3]) /* line 19 */ {
				echo '		</a>';
			}
			echo '</b> napsal:</p>
';
			if ($ʟ_if[1] = ($important)) /* line 22 */ {
				echo '        <strong>';
			}
			echo ' Dobrý den! ';
			if ($ʟ_if[1]) /* line 22 */ {
				echo '</strong>
';
			}
			echo "\n";
			if ($important) /* line 24 */ {
				echo '<strong>';
			}
			echo ' Dobrý den! ';
			if ($important) /* line 24 */ {
				echo '</strong>';
			}
			echo '

		<div>';
			echo LR\Filters::escapeHtmlText($comment->content) /* line 26 */;
			echo '</div>
';
			$iterations++;
		}
		echo '</div>



';
	}


	/** {block title} on line 7 */
	public function blockTitle(array $ʟ_args): void
	{
		extract($this->params);
		extract($ʟ_args);
		unset($ʟ_args);
		echo '<h1>';
		echo LR\Filters::escapeHtmlText($post->title) /* line 7 */;
		echo '</h1>
';
	}

}
