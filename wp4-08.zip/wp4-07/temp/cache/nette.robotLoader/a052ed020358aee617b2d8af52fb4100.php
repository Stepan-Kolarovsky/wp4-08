<?php
return array (
  0 => 
  array (
    'App\\Bootstrap' => 
    array (
      0 => '/wp4-07/app/Bootstrap.php',
      1 => 1636563719,
    ),
    'App\\Presenters\\Error4xxPresenter' => 
    array (
      0 => '/wp4-07/app/Presenters/Error4xxPresenter.php',
      1 => 1636563719,
    ),
    'App\\Presenters\\EditPresenter' => 
    array (
      0 => '/wp4-07/app/Presenters/EditPresenter.php',
      1 => 1642584862,
    ),
    'App\\Presenters\\HomepagePresenter' => 
    array (
      0 => '/wp4-07/app/Presenters/HomepagePresenter.php',
      1 => 1639579924,
    ),
    'App\\Presenters\\PostPresenter' => 
    array (
      0 => '/wp4-07/app/Presenters/PostPresenter.php',
      1 => 1641980122,
    ),
    'App\\Presenters\\ErrorPresenter' => 
    array (
      0 => '/wp4-07/app/Presenters/ErrorPresenter.php',
      1 => 1636563719,
    ),
    'App\\Router\\RouterFactory' => 
    array (
      0 => '/wp4-07/app/Router/RouterFactory.php',
      1 => 1636563719,
    ),
  ),
  1 => 
  array (
    'App\\Presenters\\HomepageDefaultTemplate' => 3,
    'App\\Presenters\\HomepageTemplate' => 3,
    'App\\Presenters\\PostShowTemplate' => 3,
    'App\\Presenters\\PostTemplate' => 3,
    'App\\Presenters\\EditEditTemplate' => 3,
    'App\\Presenters\\EditTemplate' => 3,
    'App\\Presenters\\EditCreateTemplate' => 2,
  ),
  2 => 
  array (
  ),
);
